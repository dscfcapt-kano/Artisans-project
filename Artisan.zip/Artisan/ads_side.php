<?php



                               $result = ORM::for_table("table_ads")
                                       ->find_array();
                           ?>
                             <?php  foreach ($result as $ads):?>
                             
<div class="panel panel-body text-center"><?php echo $ads['side_ads']; ?></div>
        
        
        
                           <?php endforeach;?>					