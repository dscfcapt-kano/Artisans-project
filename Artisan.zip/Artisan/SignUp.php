<?php
$servername="localhost";
$username="root";
$password="";
$database="newdata";
$conn=mysqli_connect($servername, $username, $password, $database);
if(!$conn){
die("Connection failed".mysqli_connect_error());
}
if(isset($_POST['loginBtn'])){
$username=$_POST['username'];
$password=$_POST['password'];
if(empty($username)){
$username_err="Please enter your username";
}
if(empty($password)){
$password_error="Please enter your password";
}
}
if($username_error="" && $password_error=""){
session_start();
$_SESSION['login_user']=$username;
 
$query = "SELECT username FROM member WHERE username='$username' and password='$password'";

 if(mysqli_num_rows($query)!=0)
{

header("Location:Profile.php");
  }

  else
  {
$user_not_found="Invalid username or password";
}
}

?>
<!DOCTYPE html>
<html>
<head>
<style type="text/css">
.form{
width:100%;
height:auto;
box-shadow:3px 3px 3px gray;
}
input:hover{
width:98%;
height:25px;
border:none;
background-color:transparent;
outline:none;
border-bottom:2.3333333px solid #007bff;
}
input{
width:98%;
height:25px;
border:none;
background-color:transparent;
outline:none;
border-bottom:2.3333333px solid gray;}</style>
<script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
<script src="lib/jquery/jquery.min.js"></script>
 <script src="lib/jquery/jquery-migrate.min.js"></script>
 <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="lib/superfish/hoverIntent.js"></script>
 <script src="lib/superfish/superfish.min.js"></script>
 <script src="lib/easing/easing.min.js"></script>
 <script src="lib/modal-video/js/modal-video.js"></script>
 <script src="lib/owlcarousel/owl.carousel.min.js"></script>
 <script src="lib/wow/wow.min.js"></script>
<script type="text/javascript" src="lib/jquery/jquery.min.js"></script>
<link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<meta content="width=device-width, initial-scale=1" name="viewport"  >
<title>Artisans Meet •Log in</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a style="font-family:'comic sans';" class="navbar-brand" href="index.php">Artisans Meet
</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About Us</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Categories  
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">More...</a>
          <a class="dropdown-item" href="#">More...</a>
           <a class="dropdown-item" href="#">More...</a>
          <a class="dropdown-item" href="#">More...</a>
        </div>
      </li>
    </ul>
</div>
</nav>
<div class="container" >
<div class="row" >
<div class="col-md-12 col-lg-6" >
<b><h2> Log in :</h2></b>
<div align="center"  class="form">
<form action="login.php" method="post"> 
<span class="text-danger">
 <?php echo $user_not_found;?>
 </span>
<div class="form-group">
<input type="text" name="username" placeholder="Username" value="<?php echo $username;?>" >
<span class="text-danger">
<?php echo $username_err; ?>
</span>
</div>
<div class="form-group" >
<input type="password"  name="password" placeholder="Password">
<span class="text-danger">
<?php echo $password_error; ?>
</span>
</div>
<button type="submit" name="loginBtn" class="btn btn-primary"  >Log in</button>
</form>
</div>
</div>
</div>
</div>
<div id="footer" class="text-light bg-dark col-lg-12 col-md-12"  >
FAQ &nbsp; &nbsp; &nbsp; &nbsp; About us &nbsp;  Terms & Conditions<br>
</div>
</body>
</html>