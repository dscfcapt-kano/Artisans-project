<?php


?>  <div class="col-sm-4">       
      
 <?php
                           
				$result = $db->prepare("SELECT * FROM settings");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
                                   
                                    

                
               ?>   
     

                                <?php }?>
								   
                                                                      
                            


      
      
      <br><br><br><br><br><br>
      <?php
                           
				$result = $db->prepare("SELECT * FROM youtube");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++){
                                    
                              

                
               ?> 
           
              
                                                                      <div class="panel panel-body hidden-xs" > 
                                                                          
                                                                          <?php
                                                                           preg_match("#(?<=v=)[a-zA-Z0-9-]+(?=&)|(?<=v\/)[^&\n]+(?=\?)|(?<=v=)[^&\n]+|(?<=youtu.be/)[^&\n]+#", $row['youtube_url'], $matches);
        ;
                                                                          ?>
							 <iframe width="100%" height="214"
                                                                 
                                                                 src="http://www.youtube.com/embed/<?=$matches[0]?>?autoplay=0">
</iframe> 	 
                                                                                                                                  
                                                                      </div>
                                                                          
                                <?php }?>

                                                                  
                                                  <div class="clearfix"></div>                      
									  <div class="panel panel-default hidden-xs">
                                                                              <div class="panel-heading scode"><font style="color: #D75B5B"><h4>ARTICLES</h4></font></div>
										<div class="panel-body">
											<ul class="">
                                                                                               <?php
                           
				$result = $db->prepare("SELECT * FROM posts_tbl ORDER BY RAND() limit 0,15");
				$result->execute();
				for($i=0; $row = $result->fetch(); $i++)
                                {        
?>
				
                                                                                            <p>  <li class="text-left" style="color: #FFF"><a href="login.php?id=<?php echo $row['id'];?>"><?php echo $row['post_title'];?></a></li><p>
                                                                  
                                                                   <?php }
             ?>
								</ul>  <hr>    </div>
                                                                               
									  </div>
                                                                      
                                                         
                             
                     				   <div class="panel panel-default hidden-xs  ">
          <div class="panel-heading scode"> <font style="color: #D75B5B"><h4>CATEGORIES</h4></font></div>
          <div class="">
										        <?php
                               $result = ORM::for_table("cat_tbl")
                                       ->find_array();
                           ?>
                             <?php  foreach ($result as $ads):?>
              <ul>
        
                  <p>  <li style="color: #D75B5B"><a href="login.php?id=<?php echo $ads['id'];?>"><?php echo $ads['post_cat'];?></a></li><p>
                                                                                 	
              </ul>			
								   	
                           <?php endforeach;?>
          </div>
                                                                  </div>
