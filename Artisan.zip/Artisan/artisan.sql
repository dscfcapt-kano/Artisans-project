-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 02, 2019 at 04:08 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `artisan`
--
CREATE DATABASE IF NOT EXISTS `artisan` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `artisan`;

-- --------------------------------------------------------

--
-- Table structure for table `cat_tbl`
--

CREATE TABLE IF NOT EXISTS `cat_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_cat` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `cat_tbl`
--

INSERT INTO `cat_tbl` (`id`, `post_cat`) VALUES
(1, 'Business'),
(2, 'Lifehack'),
(3, 'Entreprenourship'),
(4, 'Engineering'),
(5, 'Cusmetics'),
(6, 'Programming and IT'),
(8, 'Plumbing '),
(9, 'Mechanics'),
(10, 'Tailoring '),
(11, 'Hip Hop '),
(12, 'Education'),
(13, 'Boutiques'),
(14, 'Sport');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `bio` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`id`, `firstname`, `lastname`, `username`, `password`, `gender`, `bio`) VALUES
(1, 'Umar', 'Shuaibu Nuhu', 'umarsnuhu', '123456', 'Male', 'i UmarShuaibu i started my business sense 1998'),
(2, 'garba', 'umar', 'garba', '123456', 'male', 'my name is garba'),
(4, 'hajar', 'nuhu', 'hajara', '123456', 'Female', 'her name is Hajara');

-- --------------------------------------------------------

--
-- Table structure for table `posts_tbl`
--

CREATE TABLE IF NOT EXISTS `posts_tbl` (
  `id` int(112) NOT NULL AUTO_INCREMENT,
  `post_title` varchar(300) NOT NULL,
  `post_cat` varchar(150) NOT NULL,
  `post_tag` varchar(100) NOT NULL,
  `post_body` varchar(2000) NOT NULL,
  `date` date NOT NULL,
  `file` varchar(700) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `posts_tbl`
--

INSERT INTO `posts_tbl` (`id`, `post_title`, `post_cat`, `post_tag`, `post_body`, `date`, `file`) VALUES
(21, 'Artisan Skills Training: A Career as a Tiler', '4', 'Engineering', ' People who enjoy mathematics have great motor skills and who like practical work may consider becoming a qualified tiler.\r\n\r\nTilers can work across a broad range of spaces such as homes, or commercial, corporate or industrial sites. They can also work with wide range of tile materials such as granite, marble, stone, slate, quartz, ceramic, porcelain and glass. On a typical day, a tiler will prepare the area to be tiled, cut the tiles and lay the tiles. After the tiles are correctly laid, adhesive is spread over the tiles to seal them into place.\r\n\r\nSkills a tiler needs\r\nAs a tiler you would cover walls or floors with tiles, on jobs ranging from tiling a kitchen or bathroom, to fitting out a shop, hotel or restaurant. Some tilers also carry out specialist work, for instance on swimming pools and mosaic walls found in landscape gardening. To be good at this job you will also need to be able to work accurately. You will need number skills to calculate costs and quantities of materials. Tilers also need to have good hand-eye coordination and good eyesight, have a good idea about space and have a creative imagination.\r\n\r\nPros and cons of tiling\r\nTiling can be incredibly affordable, and there''s a ton of variety in styles, colors, finishes and textures. It''s also easy to customize it for details like chair rails, soap dishes and special edging and nosing. You can work in any type of weather as a tiler unlike other trades such as carpenting and bricklaying, as tiling can be undertaken both outdoors and indoors. It''s also not a heavy-laboured job. The money is good and there are plenty of opportunities for employment.\r\n\r\nSteps to becoming a tiler\r\nYou can complete a artisan training course that trains and qualifies you as a professional tiler. You can find such courses advertised in the Engineering and Artisans Training section..', '2019-04-24', 'eblog_8b6e9efc3915774e27307037fe4448f3.jpeg'),
(22, 'What is the cost of higher education?', '4', 'Engineering', ' SA tertiary education needs to be massively subsidised â€“ especially mid-level skills like apprentices says ATI.\r\n\r\nIt will cost the government and the economy a further R71 billion to fund tertiary education, but, in the light of the recent student protests, it is clear that this is a decision that needs to be taken â€“ and the necessary funds need to be found.\r\n\r\nThe further R71 billion that will be required is up from the current R25 billion per year which is already spent on tertiary education\r\n\r\nThere arguably also has to be more attention placed on fine-tuning mid-level skills, like artisan apprentices, said Sean Jones, co-founder and director of black empowered private training company, Artisan Training Institute (ATI).\r\n\r\nâ€œWhen it comes to mid-level skills like apprentices â€“ including diesel engineers, tractor mechanics and fitters and turners â€“ jobs are more easily created. There needs to be more of a focus in this area, also because we have an ongoing, and severe, shortage of trained artisans across a myriad of disciplines.â€\r\n\r\nThere is purported to be a shortfall of 30 000 artisans currently facing the SA economy.\r\n\r\nCommenting further, Jones said: Given the recent student unrest â€“ which rocked the nation â€“ it has become clear that tertiary education needs to be massively subsidised. If not the unrest will continue and we will end up with an uneducated youth â€“ as students will simply not be able to afford their fees.â€\r\n\r\nâ€œIt is as simple as that. At the very least, undergraduates need to be given free, or near to free, education.â€\r\n\r\nA recent report stated that the government and universities will need around R6.2 billion to cover the funding gap brought about as a result of the freeze in the tertiary fee increases agreed to at a meeting with President Zuma earlier this month.\r\n\r\nBut that is a drop in the ocean compared to the total figure required.\r\n\r\nIf higher education was to be funded solely through taxpayer subsidies, then a fur', '2019-04-24', 'eblog_7ff3a574a53e3243197d95fe6cb44c70.jpg'),
(23, 'Learning to become an artisan', '12', 'Education', ' ould you like to become an artisan? There is a huge demand for qualified artisans in South Africa and now is a good time to pursue this line of work. But first, let''s take a look at exactly what an artisan is:\r\n\r\nWhat is an artisan?\r\nAn artisan is a person who is highly skilled with their hands. That is, an artisan works primarily in a technical field, doing skilled manual labour. This may be as a plumber, electrician, carpenter and many other fields.\r\n\r\nHow do I become an artisan?\r\nIn order to become an artisan, you will have to pass a Trade Test in your field in order to be nationally recognised as an artisan. But first, you''ll need to attend a TVET college in order to learn the theoretical skills needed to study the practical skills necessary to become an artisan.\r\n\r\n\r\n\r\n\r\n\r\n\r\nAspiring artisans must begin by selecting a particular field of work. For example, within the artisan sector there are opportunities to become an electrician, mechanic, plumber, carpenter or joiner, to name just a few. For those who want to further develop their skills there are technician or engineering related jobs. As you can see, these are all highly practical yet skilled jobs.\r\n\r\nWhile artisan learning programmes are largely practical there is a substantial amount of theory that must be obtained at a school or vocational college. In order to train at a vocational college learners must meet the necessary requirements.\r\n\r\nAdmission Requirements\r\nThe minimum requirements to enter a recognized learning programme to become an artisan are outlined in the new Draft Trade Test regulations. Students who wish to apply for entrance must achieve 40% for mathematics (excluding maths literacy) and a Grade 9 or National Certificate level 2 pass.\r\n\r\nIn the case of civil, mechanical and electrical categories of trades a minimum of 40% in the relevant N2 Trade theory or the relevant vocational subjects of the National Certificate (Vocational) Level 2 is required.\r\n\r\nOccupational Knowledge\r\nStudents wil', '2019-04-24', 'eblog_188d0869bee8beac09e278da5a017307.jpg'),
(25, 'Consider a career as an artisan', '12', 'Education', 'Currently the failure rate at universities is sitting around 50%, with many students not suitably prepared for tertiary education. The solution to this dilemma is for youth to consider a career as an artisan, as there is quicker access to full-time employment â€“ with apprentices often getting an apprenticeship with a company in their first year. Critically, this means they also start earning money far sooner.\r\n\r\nThis is according to Sean Jones, CEO of black empowered Artisan Training Institute (ATI). â€œA 50% failure rate at university is far too high, meaning many students are out of their depth. If they opt, instead, to enrol for artisan training they will get an apprentice placement with an employer literally from the time of enrolment and earn a stipend, from the employer, from their first year of training. Almost all our learners are assigned to an employer from enrolment stage.â€\r\n\r\nFrequently, students will study at university for three to four years and, upon graduation, many struggle to obtain gainful employment. Graduates in most cases earn rock bottom salaries as there is an oversupply of their skill and knowledge offering. Many, with degrees who are not absorbed into large corporate companies, end up working as waiters or waitresses, or other semi-skilled jobs such as sales assistants or in security for example.\r\n\r\nArtisans, however, are almost guaranteed formal employment and, upon graduation can earn R20 000 to R25 000 per month. Thatâ€™s more than most university graduates will earn.\r\n\r\nâ€œThe economy desperately needs these mid-level skills â€“ artisans are a vital cog of the economy,â€ said Jones.\r\n\r\nAdditionally, becoming an artisan â€“ whether it is as a nurse, baker, electrician, diesel mechanic or tractor technician for example, is a springboard to other careers in engineering, sales, training, management or entrepreneurship.\r\n\r\nJones said it is a pity that many families eschew the vocational training option, as there is a far greater need fo', '2019-04-24', 'eblog_974dd6546bb29acd0d14fc63234cdd5b.gif'),
(27, 'How to become a plumber', '12', 'Education', 'Do you want to be your own boss? Do you like working with your hands? Being a plumber has many perks but it can also require long, unscheduled work hours. If you think this profession would suit you find out how to become a plumber.\r\n\r\nRegardless of the economic situation in the country there will always be a need for plumbers.One of the advantages of becoming a plumber is the reliability of this career. Regardless of the economic situation in the country there will always be a need for plumbers.\r\n\r\nWhich skills do plumbers need?\r\nGenerally plumbers are good at problem solving, have the ability to follow technical plans, and understand the importance of health and safety. People skills are also important.\r\n\r\nPlumbers don''t need to have a college degree but industry-recognised training is required to become a qualified practitioner. A common entry way into the plumbing industry is through an apprenticeship. There are a variety of plumber apprenticeships and courses available in South Africa.\r\n\r\nDuring training you will learn how to install water supplies, find faults, fix domestic appliances and attend to emergency call-outs, among other things.\r\n\r\nThe Construction Education and Training Authority (CETA) is responsible for evaluating and accrediting all suitable training courses for use by prospective plumbers. You will need to complete Ceta accredited training in order to become a licensed plumber.\r\n\r\nOnce you have the required skills you will be in demand and have the ability to earn a decent wage as a plumber in South Africa.\r\n\r\nYou will probably start your career as an assistant plumber where you will work alongside an experienced and qualified plumber while servicing residences.\r\n\r\nWork opportunities for plumbers\r\nAs you gain experience you will be able to explore opportunities in the field of building maintenance. This will mean resolving issues as they arise and doing general maintenance tasks.\r\n\r\nThere are many opportunities in plumbing in South Africa. Some ', '2019-04-24', 'eblog_fdcc1724dff511d2d18349d0611ad6c6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `quote`
--

CREATE TABLE IF NOT EXISTS `quote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quote` varchar(300) NOT NULL,
  `quote_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `quote`
--

INSERT INTO `quote` (`id`, `quote`, `quote_by`) VALUES
(1, 'Articles on Engineering and Artisan Training', 'Umar Shuaibu Nuhu');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(45) NOT NULL,
  `site_title` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `site_desc` varchar(350) NOT NULL,
  `site_keyword` varchar(250) NOT NULL,
  `google_code` varchar(1000) NOT NULL,
  `street` varchar(100) NOT NULL,
  `city` varchar(60) NOT NULL,
  `country` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `facebook` varchar(45) NOT NULL,
  `twitter` varchar(34) NOT NULL,
  `linkedin` varchar(45) NOT NULL,
  `status` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_name`, `site_title`, `email`, `site_desc`, `site_keyword`, `google_code`, `street`, `city`, `country`, `phone`, `facebook`, `twitter`, `linkedin`, `status`) VALUES
(1, 'Artisans Meet', 'Artisans Skills', 'Atrisans@gmail.com', 'Skills For Success', 'Search Engine Ready, Business and others', '', 'Aminu kano Way', 'Kano', 'Nigeria', '+234-7067612299', 'dankurai', '@umarshuaibunuhu', 'umarshuaibunuhu', 'Good to Go');

-- --------------------------------------------------------

--
-- Table structure for table `table_admin`
--

CREATE TABLE IF NOT EXISTS `table_admin` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `file` varchar(567) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `table_admin`
--

INSERT INTO `table_admin` (`id`, `name`, `email`, `username`, `password`, `file`) VALUES
(1, 'u', 'umar@gmail.com', 'umar', 'u', ''),
(2, 'Ibrahim Hassan ', 'ib@gmail.com', 'ib', '12345', 'your_site_name_d5bfad56e93f4347d9539987d9f81f78.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `table_ads`
--

CREATE TABLE IF NOT EXISTS `table_ads` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `header_ads` varchar(500) NOT NULL,
  `side_ads` varchar(500) NOT NULL,
  `footer_ads` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `table_ads`
--

INSERT INTO `table_ads` (`id`, `header_ads`, `side_ads`, `footer_ads`) VALUES
(1, '<!-- Adtall - Ad Display Code -->\r\n<script type="text/javascript" src="//www.adtall.com/display/js/ads.js?822&522&728&90&0"></script>\r\n<!-- Adtall - Ad Display Code -->', '<!-- Adtall - Ad Display Code -->\r\n<script type="text/javascript" src="//www.adtall.com/display/js/ads.js?821&522&300&250&0"></script>\r\n<!-- Adtall - Ad Display Code -->', '!-- Adtall - Ad Display Code -->\r\n<script type="text/javascript" src="//www.adtall.com/display/js/ads.js?821&522&300&250&0"></script>\r\n<!-- Adtall - Ad Display Code -->');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_about`
--

CREATE TABLE IF NOT EXISTS `tbl_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` varchar(2500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_about`
--

INSERT INTO `tbl_about` (`id`, `body`) VALUES
(4, ' <p>All <em>Idiorm</em> queries start <em>with</em> a call to the for_table static method on the <em>ORM</em> class. ... Method calls which <em>add</em> filters and constraints to your query are then strung together ... either a single instance of the <em>ORM</em> class representing the <em>database</em> row you ...... The <em>ORM</em> class instance(s) returned will contain <em>data</em> for all the columnsÂ ...</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_resources`
--

CREATE TABLE IF NOT EXISTS `tbl_resources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_resources`
--

INSERT INTO `tbl_resources` (`id`, `body`) VALUES
(1, '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. <a href="http://localhost/konblog/index.php">Sed tortor.</a> Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `user_online`
--

CREATE TABLE IF NOT EXISTS `user_online` (
  `session` varchar(100) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_online`
--

INSERT INTO `user_online` (`session`, `time`) VALUES
('akdl10dmsojkvvjasmj2tmt221', 1556670783),
('u4dvviq34hsct08rapafa30to1', 1556670818);

-- --------------------------------------------------------

--
-- Table structure for table `youtube`
--

CREATE TABLE IF NOT EXISTS `youtube` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `youtube_url` varchar(200) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `youtube`
--

INSERT INTO `youtube` (`id`, `youtube_url`, `date`) VALUES
(1, 'https://youtu.be/JdABpvWWgCU', '2016-04-20');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
