<?php

/* Database config */
$db_host		= "localhost";
$db_user		= "root";
$db_pass		= "";
$db_database	= "artisan";
include "idiorm.php";
/* End config */
 ORM::configure("mysql:host=".$db_host.";dbname=".$db_database);
 ORM::configure("username",$db_user);
 ORM::configure("password",$db_pass);


$db = new PDO("mysql:host=".$db_host.";dbname=".$db_database, $db_user, $db_pass);
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$conn = mysql_connect($db_host, $db_user,$db_pass);
mysql_select_db($db_database);
$mysqli = new mysqli;


